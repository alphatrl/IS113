<?php

/*
    Name:

    Email:
*/

require_once 'include/common.php';

// Clear previously stored cart
if( isset ($_SESSION['cart']) ) {
  unset($_SESSION['cart']);
}

?>

<html>
<head>
  <title>Show All Items in Current Inventory</title>
</head>
<body>

  <h2>All Available Items</h2>

  <form method='POST' action='cart.php'>

    <table border='1'>
      <tr>
        <th>Item ID</th>
        <th>Item Name</th>
        <th>Quantity</th>
        <th>Price (per item)</th>
      </tr>

    </table>
    <br>
    <input type='submit' value='Add Items to Cart'>

  </form>


</body>
</html>
