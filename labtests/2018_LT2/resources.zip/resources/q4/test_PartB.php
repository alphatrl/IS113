<?php

require_once 'include/common.php';

$origin = 'JFK';
$destination = 'SFO';

$dao = new RouteDAO();
$route = $dao->getMultiHopRoute($origin, $destination);

echo $route;

?>
