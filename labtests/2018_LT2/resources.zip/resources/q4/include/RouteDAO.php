<?php

/*
    Name:

    Email:
*/

require_once 'common.php';

class RouteDAO {

  // This method returns a 2-dimensional array, a distance array with travel time.
  function getDistanceArrayTime() {
    $conn_manager = new ConnectionManager();
    $conn = $conn_manager->getConnection();

    $sql = "SELECT origin, destination, travel_time FROM route";

    $stmt = $conn->prepare($sql);
    $stmt->setFetchMode(PDO::FETCH_ASSOC);
    $stmt->execute();

    $distance_array = [];
    while( $row = $stmt->fetch() ) {
      $distance_array[$row['origin']][$row['destination']] = $row['travel_time'];
    }

    $stmt->closeCursor();
    $conn = null;

    return $distance_array;
  }

  // This method returns a 2-dimensional array, a distance array with travel cost.
  function getDistanceArrayCost() {
    $conn_manager = new ConnectionManager();
    $conn = $conn_manager->getConnection();

    $sql = "SELECT origin, destination, travel_cost FROM route";

    $stmt = $conn->prepare($sql);
    $stmt->setFetchMode(PDO::FETCH_ASSOC);
    $stmt->execute();

    $distance_array = [];
    while( $row = $stmt->fetch() ) {
      $distance_array[$row['origin']][$row['destination']] = $row['travel_cost'];
    }

    $stmt->closeCursor();
    $conn = null;

    return $distance_array;
  }

  // Question 4 - Part A
  // Given a route, this method returns an an associative array
  // containing two weights:
  //   - Total Time
  //   - Total Cost
  function getWeights($route) {
    // Given this input:
    //    JFK-->DEN-->SFO
    //
    // Calculate total time & total cost along this route
    //
    //   Total Time:
    //     JFK-->DEN: 4
    //     DEN-->SFO: 2
    //   Then, the total time is 4 + 2 ==> 6
    //
    //   Total Cost:
    //     JFK-->DEN: 8000
    //     DEN-->SFO: 4000
    //   Then, the total cost is 8000 + 4000 ==> 12000
    //
    // Return an associative array

    $weights = [
                  'total_time' => 6,
                  'total_cost' => 12000
               ];


    return $weights;
  }

  // Question 4 - Part B
  // This method finds ONE multi-hop route from origin to destination.
  // It returns a route as a string.
  function getMultiHopRoute($origin, $destination) {
    // There may be MANY routes from $origin to $destination.
    // Code here to find ONE route and return it as a string.
    // For example:
    //
    // Origin:      JFK
    // Destination: SFO
    //
    // You can return any of the following:
    //
    // JFK --> SFO
    // JFK --> DEN --> SFO
    // JFK --> ATL --> LAX --> SFO
    // and other routes...
    $route = 'JFK-->DEN-->SFO';

    return $route;
  }

  // Question 4 - Part C
  // Given Origin, Destination, Optimization Type
  // Return the most optimal route.
  function getBestRoute($origin, $destination, $optimize_by) {

    $distance_array = [];
    if($optimize_by == 'time') {
      $distance_array = $this->getDistanceArrayTime();
    }
    else {
      $distance_array = $this->getDistanceArrayCost();
    }

    // Code here

    $optimal_route = 'ATL-->LAX-->SFO';
    $total_weight = 300;

    $best_route =
    [
      'optimal_route' => $optimal_route,
      'total_weight' => $total_weight
    ];

    return $best_route; // Return the best route as an Associative Array
  }

}

?>
