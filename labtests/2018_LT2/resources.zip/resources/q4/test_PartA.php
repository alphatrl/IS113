<?php

require_once 'include/common.php';

$route = 'JFK-->DEN-->SFO';

$dao = new RouteDAO();
$weights = $dao->getWeights($route);

echo "For route:<br>$route<br><br>";
foreach($weights as $key=>$value) {
  echo "$key: $value<br>";
}

?>
