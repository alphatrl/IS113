<?php

/*
    Name:

    Email:
*/

require_once 'include/common.php';

$dao = new RouteDAO();

?>
<html>
<head>
	<title>Air Freight - Route Search</title>

</head>

<body>

	<h2>Air Freight - Route Search</h2>

  <form method='GET' action='route-search.php'>

		<table>

      <tr>
        <td>Origin</td>
        <td>
					<select name='origin'>
            <option value='ATL'>ATL</option>
						<option value='DEN'>DEN</option>
						<option value='DFW'>DFW</option>
						<option value='JFK'>JFK</option>
						<option value='LAX'>LAX</option>
						<option value='MSP'>MSP</option>
						<option value='ORD'>ORD</option>
						<option value='SFO'>SFO</option>
					</select>
        </td>
      </tr>

			<tr>
				<td>Destination</td>
				<td>
					<select name='destination'>
						<option value='ATL'>ATL</option>
						<option value='DEN'>DEN</option>
						<option value='DFW'>DFW</option>
						<option value='DTW'>DTW</option>
						<option value='JFK'>JFK</option>
						<option value='LAX'>LAX</option>
						<option value='MSP'>MSP</option>
						<option value='ORD'>ORD</option>
						<option value='SFO'>SFO</option>
					</select>
				</td>
			</tr>

      <tr>
        <td>Optimize By</td>
				<td>
					<input type='radio' name='optimize_by' value='time' checked>Least Travel Time
					<br>
					<input type='radio' name='optimize_by' value='cost'>Least Cost
				</td>
      </tr>

      <tr>
        <td colspan=2><input type='submit' value='Find Best Route'></td>
      </tr>

		</table>

	</form>
</body>
</html>
