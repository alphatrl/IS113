<?php

/*
    Name:

    Email:
*/

require_once 'include/common.php';

// Form Input Fields
$origin = $_GET['origin'];
$destination = $_GET['destination'];
$optimize_by= $_GET['optimize_by'];

// Get the best route
$dao = new RouteDAO();
$best_route = $dao->getBestRoute($origin, $destination, $optimize_by);

?>

<html>
<head>
  <title>Airfreight - Search Results</title>
</head>
<body>

  <h2>Best Route</h2>

    <table border='1'>

      <tr>
        <td>Origin</td>
        <td><?php echo $origin ?></td>
      </tr>

      <tr>
        <td>Destination</td>
        <td><?php echo $destination ?></td>
      </tr>

      <tr>
        <td>Optimize By</td>
        <td><?php echo $optimize_by ?></td>
      </tr>

      <?php
        if( $best_route == null || empty($best_route) ) {
          echo "<tr>
                  <td colspan='2'><font color='red'>Unable to find an available route</font></td>
                </tr>";
        }
        else {
      ?>
          <tr>
            <td>Best Route</td>
            <td><?php echo $best_route['optimal_route'] ?></td>
          </tr>

          <tr>
            <td>Total Weight</td>
            <td><?php echo $best_route['total_weight'] ?></td>
          </tr>

      <?php
      }
      ?>
    </table>

</body>
</html>
