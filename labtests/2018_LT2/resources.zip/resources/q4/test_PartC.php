<?php

require_once 'include/common.php';

$origin = 'ATL';
$destination = 'SFO';
$optimize_by = 'time';

$dao = new RouteDAO();
$route = $dao->getBestRoute($origin, $destination, $optimize_by);

var_dump($route);

?>
