<?php
/*
    Name:

    Email:
*/
?>

<html>
<head>
  <title>Customer Search All</title>
</head>
<body>
  <h2>All Customers</h2>

  <table border='1'>
    <tr>
      <th>ID</th>
      <th>Gender</th>
      <th>Age</th>
      <th>Music</th>
      <th>Fashion</th>
      <th>Sports</th>
      <th>Electronics</th>
    </tr>

  </table>

</body>
</html>
