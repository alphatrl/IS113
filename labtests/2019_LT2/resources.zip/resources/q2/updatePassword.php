<?php
/*
    Name:

    Email:
*/

require_once 'model/common.php';
require_once 'model/protect.php';

# == Part C : ENTER CODE HERE == 



function generateRandomPassword() {
# == Part C : ENTER CODE HERE == 


}

?>